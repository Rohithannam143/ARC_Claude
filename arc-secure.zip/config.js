// Public client config only (these values are safe to expose). NEVER put the Groq key, service-role key or JWT secret here.
window.ARC_CONFIG = {
  firebase: { apiKey: "YOUR_FIREBASE_API_KEY", authDomain: "YOUR_PROJECT.firebaseapp.com", projectId: "YOUR_PROJECT_ID", appId: "YOUR_APP_ID" },
  supabaseUrl: "https://YOUR_REF.supabase.co",
  supabaseAnon: "YOUR_SUPABASE_ANON_KEY"
};
