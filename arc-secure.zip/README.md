# ARC AI — secure setup

**Stack:** static site (`index.html`, `app.js`, `vendor/`) · Firebase Auth · Supabase (Postgres + Storage + Edge Function) · Groq.
All third‑party JS is **self‑hosted** (no CDN → no supply‑chain injection); strict CSP allows only `'self'` scripts.

## 1. Firebase
1. Authentication → enable **Email/Password**. Settings → **Authorized domains**: only your domain.
2. Authentication → Settings → enable **Email enumeration protection** and a **password policy** (min 10 chars).
3. Google Cloud Console → APIs & Services → Credentials → restrict the browser API key to **HTTP referrers = your domain** and to the Identity Toolkit / Token Service APIs.
4. (Recommended) App Check with reCAPTCHA Enterprise for Auth.
5. Put the web config in `config.js`.

## 2. Supabase
1. SQL Editor → run `schema.sql` (safe to re‑run).
2. **Authentication → Sign In / Providers: turn OFF "Allow new users to sign up", Email, and Anonymous sign‑ins.** (Firebase is your only login; RLS also requires the `app=arc` claim as defense in depth.)
3. Copy `arc-function.ts` → `supabase/functions/arc/index.ts`, then:
```
supabase secrets set GROQ_API_KEY=gsk_xxx FIREBASE_PROJECT_ID=your-id JWT_SECRET=<Supabase JWT secret> ALLOWED_ORIGINS=https://your-domain.com
supabase functions deploy arc --no-verify-jwt
```
Secrets live only in the function. **Never** put the Groq key, service‑role key or JWT secret in `config.js`/git. Rotate immediately if leaked.
4. `config.js`: Supabase URL + anon key (public by design).

## 3. Host (HTTPS only)
Deploy this folder to Netlify / Cloudflare Pages (uses `_headers`) or Vercel (uses `vercel.json`). **Replace `YOUR_REF` in the CSP** with your Supabase project ref. The headers file is required for `frame-ancestors`, HSTS, etc. (meta CSP cannot set them).
Rebuild after editing `app.src.js`: `npm i && npm run build`.

## Security controls
- **AuthN:** Firebase; verified email required (server‑enforced); 30‑min idle sign‑out; generic auth errors; 10+ char passwords.
- **AuthZ:** Postgres RLS on notes + storage, per‑user folders, `user_id` immutable, DB‑side limits (sizes, 5000 notes, mime allow‑list, 20 MB).
- **Tokens:** Edge Function verifies Firebase JWT (RS256, issuer, audience) → 15‑min Supabase token.
- **AI proxy:** fixed server‑side prompts, input caps, 10/min & 200/day per user (DB‑backed), origin allow‑list, 25 s timeout, no upstream error leakage; notes treated as untrusted data (prompt‑injection guard); AI output only ever rendered as text.
- **XSS:** DOMPurify (no img/svg/form/style, http(s)/mailto only), Mermaid `strict`, flashcards built with `textContent`, CSP `script-src 'self'`, no inline JS.
- **Uploads:** extension + magic‑byte checks, binary‑in‑text rejection, zip‑bomb limits, 200‑page PDF cap, pdf.js `isEvalSupported:false`, own XLSX parser (SheetJS npm build has known CVEs).
- **Privacy:** "Delete all my data" in Settings; signed download links expire in 2 min.

## Known limits
Firebase tokens are checked for signature/expiry, not revocation (≤15 min exposure after disabling a user). CSP keeps `style-src 'unsafe-inline'` (needed by Mermaid/SVG styles). No software is "vulnerability‑free": keep deps updated (`npm audit`, rebuild) and review logs.
