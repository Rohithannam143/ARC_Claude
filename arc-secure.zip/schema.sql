-- Safe to re-run. If you ran an older version of this file with existing test data you don't need, first run:  drop table if exists notes cascade;
create table if not exists notes (
  id uuid primary key default gen_random_uuid(),
  user_id text not null default (auth.jwt()->>'sub'),
  title text not null default 'Untitled' check (char_length(title) <= 200),
  subject text not null default 'General' check (char_length(subject) <= 100),
  content text not null default '' check (char_length(content) <= 2000000),
  file_path text check (file_path is null or (file_path like user_id || '/%' and char_length(file_path) <= 300)),
  file_type text check (file_type is null or file_type in ('pdf','docx','pptx','xlsx','csv','txt','md','img','code')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists notes_user_idx on notes(user_id, updated_at desc);
alter table notes enable row level security;
alter table notes force row level security;
revoke all on notes from anon;
drop policy if exists "own notes" on notes;
create policy "own notes" on notes for all to authenticated
  using (user_id = auth.jwt()->>'sub' and auth.jwt()->>'app' = 'arc')
  with check (user_id = auth.jwt()->>'sub' and auth.jwt()->>'app' = 'arc');

-- server-controlled fields: user_id immutable, updated_at forged-proof, per-user note quota
create or replace function notes_guard() returns trigger language plpgsql set search_path = public as $$
begin
  if tg_op = 'INSERT' then
    if (select count(*) from notes where user_id = new.user_id) >= 5000 then raise exception 'Note limit reached'; end if;
  else
    new.user_id := old.user_id; new.created_at := old.created_at;
  end if;
  new.updated_at := now(); return new;
end $$;
drop trigger if exists notes_guard_t on notes;
create trigger notes_guard_t before insert or update on notes for each row execute function notes_guard();

-- private bucket: 20 MB cap + mime allow-list + per-user folder isolation
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values ('files','files',false,20971520,
  array['application/pdf','application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.openxmlformats-officedocument.presentationml.presentation','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv','text/plain','image/png','image/jpeg','image/gif','image/webp'])
on conflict (id) do update set public=false, file_size_limit=excluded.file_size_limit, allowed_mime_types=excluded.allowed_mime_types;
drop policy if exists "own files" on storage.objects;
create policy "own files" on storage.objects for all to authenticated
  using (bucket_id='files' and auth.jwt()->>'app' = 'arc' and (storage.foldername(name))[1] = auth.jwt()->>'sub')
  with check (bucket_id='files' and auth.jwt()->>'app' = 'arc' and (storage.foldername(name))[1] = auth.jwt()->>'sub');

-- AI rate limiting (callable only by the Edge Function via service_role)
create table if not exists ai_usage (id bigserial primary key, user_id text not null, at timestamptz not null default now());
create index if not exists ai_usage_idx on ai_usage(user_id, at desc);
alter table ai_usage enable row level security;
revoke all on ai_usage from anon, authenticated;
create or replace function ai_rate_ok(uid text, per_min int, per_day int) returns boolean
language plpgsql security definer set search_path = public as $$
declare m int; d int;
begin
  perform pg_advisory_xact_lock(hashtext(uid));
  delete from ai_usage where user_id = uid and at < now() - interval '2 days';
  select count(*) filter (where at > now() - interval '1 minute'), count(*) filter (where at > now() - interval '1 day')
    into m, d from ai_usage where user_id = uid;
  if m >= per_min or d >= per_day then return false; end if;
  insert into ai_usage(user_id) values (uid); return true;
end $$;
revoke all on function ai_rate_ok(text,int,int) from public, anon, authenticated;
grant execute on function ai_rate_ok(text,int,int) to service_role;
