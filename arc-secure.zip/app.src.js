import {initializeApp} from "firebase/app";
import {getAuth,onAuthStateChanged,signInWithEmailAndPassword,createUserWithEmailAndPassword,sendPasswordResetEmail,sendEmailVerification,signOut} from "firebase/auth";
import {createClient} from "@supabase/supabase-js";
import {marked} from "marked";
import DOMPurify from "dompurify";
import JSZip from "jszip";

if(window.top!==window.self){document.documentElement.remove();throw new Error("framed");} // anti-clickjacking fallback
const CFG=window.ARC_CONFIG,FN=CFG.supabaseUrl+"/functions/v1/arc",IDLE_MS=30*60*1000,MAXTXT=1e6;
const auth=getAuth(initializeApp(CFG.firebase));

/* ---------- API (Firebase token -> Edge Function -> short-lived Supabase token) ---------- */
async function call(body){
  const r=await fetch(FN,{method:"POST",credentials:"omit",cache:"no-store",signal:AbortSignal.timeout(40000),
    headers:{"Content-Type":"application/json",Authorization:"Bearer "+await auth.currentUser.getIdToken()},body:JSON.stringify(body)});
  let d={};try{d=await r.json();}catch{}
  if(!r.ok)throw new Error(d.error||"Request failed ("+r.status+")");return d;}
let sTok,sExp=0,pend=null;
const supaTok=()=>!auth.currentUser?Promise.resolve(null):Date.now()<sExp-60000?Promise.resolve(sTok):(pend??=call({action:"token"}).then(d=>{sTok=d.token;sExp=d.exp*1000;return sTok;}).finally(()=>{pend=null;}));
const sb=createClient(CFG.supabaseUrl,CFG.supabaseAnon,{accessToken:supaTok});
const ai=async(mode,context="",messages=[])=>(await call({action:"ai",mode,context,messages})).text;

/* ---------- helpers ---------- */
const $=s=>document.querySelector(s),esc=s=>String(s??"").replace(/[&<>"'`]/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;","`":"&#96;"}[c]));
const fmt=d=>new Date(d).toLocaleDateString(undefined,{month:"short",day:"numeric",year:"numeric"});
const toast=(m,e)=>{const t=document.createElement("div");t.className="t"+(e?" e":"");t.textContent=String(m).slice(0,200);$("#toast").append(t);setTimeout(()=>t.remove(),3500);};
const UUID=/^[0-9a-f-]{36}$/i,safeName=s=>String(s).replace(/[^\w.\-]/g,"_").slice(0,80);
const arr=(x,n)=>Array.isArray(x)?x.slice(0,n):[];
const jparse=t=>{try{return JSON.parse(t)||{};}catch{return{};}};
const scripts={};const loadScript=src=>scripts[src]??=new Promise((ok,no)=>{const s=document.createElement("script");s.src=src;s.onload=ok;s.onerror=()=>no(new Error("Failed to load "+src));document.head.append(s);});
let P;try{const x=JSON.parse(localStorage.arcp);P={theme:x.theme==="dark"?"dark":"light",fs:[14,16,19].includes(x.fs)?x.fs:16,auto:x.auto!==false,spell:x.spell!==false};}catch{P={theme:"light",fs:16,auto:true,spell:true};}
const saveP=()=>{try{localStorage.arcp=JSON.stringify(P);}catch{}document.documentElement.dataset.theme=P.theme;document.documentElement.style.setProperty("--fs",P.fs+"px");};saveP();

/* Sanitizer: no images/forms/svg/inline style; links only http(s)/mailto, always noopener */
DOMPurify.addHook("afterSanitizeAttributes",n=>{if(n.tagName==="A"){n.setAttribute("target","_blank");n.setAttribute("rel","noopener noreferrer nofollow");}});
const clean=h=>DOMPurify.sanitize(h,{USE_PROFILES:{html:true},FORBID_TAGS:["style","form","input","button","textarea","select","iframe","object","embed","svg","math","img","video","audio","link","meta"],FORBID_ATTR:["style"],ALLOWED_URI_REGEXP:/^(?:https?:|mailto:|#)/i});
const md2html=m=>clean(marked.parse(m,{async:false}));

let notes=[],cur=null,view="dashboard",selSub=null,aiTab="chat",chat=[],cards=[],dirty=false,timer,prevOn=true,last=Date.now();

/* ---------- auth ---------- */
const AUTHERR={"auth/invalid-credential":"Invalid email or password.","auth/wrong-password":"Invalid email or password.","auth/user-not-found":"Invalid email or password.","auth/invalid-email":"Enter a valid email.","auth/too-many-requests":"Too many attempts. Try again later.","auth/email-already-in-use":"Could not create account. Try signing in or resetting your password.","auth/weak-password":"Password is too weak."};
const authMsg=e=>AUTHERR[e?.code]||"Something went wrong. Please try again.";
let signup=false;
$("#sw").onclick=e=>{e.preventDefault();signup=!signup;$("#lt").textContent=signup?"Create account":"Welcome back";$("#ls").textContent=signup?"Use 10+ characters with letters and numbers.":"Sign in to your ARC AI workspace.";$("#sw").textContent=signup?"Have an account? Sign in":"Create an account";$("#lb").textContent=signup?"Sign up":"Get Started";$("#pw").autocomplete=signup?"new-password":"current-password";};
$("#fg").onclick=async e=>{e.preventDefault();const em=$("#em").value.trim();if(!em)return toast("Enter your email first",1);
  try{await sendPasswordResetEmail(auth,em);}catch(x){if(x.code==="auth/invalid-email")return toast(authMsg(x),1);}toast("If that account exists, a reset link was sent.");};
$("#lf").onsubmit=async e=>{e.preventDefault();const em=$("#em").value.trim(),pw=$("#pw").value;
  if(signup&&(pw.length<10||!/[A-Za-z]/.test(pw)||!/\d/.test(pw)))return toast("Password: 10+ characters, letters and numbers.",1);
  $("#lb").disabled=true;
  try{if(signup){const c=await createUserWithEmailAndPassword(auth,em,pw);await sendEmailVerification(c.user);}else await signInWithEmailAndPassword(auth,em,pw);}
  catch(x){toast(authMsg(x),1);}$("#pw").value="";$("#lb").disabled=false;};
$("#vchk").onclick=async()=>{try{await auth.currentUser.reload();await auth.currentUser.getIdToken(true);}catch{}auth.currentUser?.emailVerified?boot(auth.currentUser):toast("Not verified yet. Check your inbox.",1);};
$("#vres").onclick=async()=>{try{await sendEmailVerification(auth.currentUser);toast("Verification email sent");}catch{toast("Please wait a minute before retrying.",1);}};
$("#vso").onclick=()=>signOut(auth);
const show=u=>{$("#login").hidden=!!u;$("#verify").hidden=!(u&&!u.emailVerified);$("#app").hidden=!(u&&u.emailVerified);};
function wipe(){notes=[];cur=null;chat=[];cards=[];dirty=false;sTok=null;sExp=0;$("#main").replaceChildren();$("#aip").hidden=true;}
async function boot(u){show(u);if(!u.emailVerified)return;$("#av").textContent=(u.email||"?")[0].toUpperCase();await load();go("dashboard");}
onAuthStateChanged(auth,u=>{if(!u){show(null);wipe();return;}boot(u);});
$("#av").onclick=()=>confirm("Sign out?")&&signOut(auth);
["pointerdown","keydown","touchstart","scroll"].forEach(ev=>addEventListener(ev,()=>{last=Date.now();},{passive:true}));
setInterval(()=>{if(auth.currentUser&&Date.now()-last>IDLE_MS){signOut(auth);toast("Signed out after 30 minutes of inactivity",1);}},30000);
addEventListener("beforeunload",e=>{if(dirty){e.preventDefault();e.returnValue="";}});

/* ---------- data ---------- */
async function load(){const{data,error}=await sb.from("notes").select("id,title,subject,file_type,file_path,updated_at,created_at").order("updated_at",{ascending:false}).limit(2000);
  if(error)toast(error.message,1);notes=data||[];}
const subjects=()=>{const m={};notes.forEach(n=>(m[n.subject]=m[n.subject]||[]).push(n));return m;};
const icon=s=>({pdf:"📕",docx:"📘",pptx:"📙",xlsx:"📗",csv:"📊",md:"📝",txt:"📄",img:"🖼"}[s]||"📄");

/* ---------- router ---------- */
function go(v,a){if(!auth.currentUser?.emailVerified)return;view=v;document.querySelectorAll("nav a[data-v]").forEach(x=>x.classList.toggle("on",x.dataset.v===v||(v==="note"&&x.dataset.v==="library")));
  ({dashboard,import:imp,library,settings,note:openNote,search})[v]?.(a);scrollTo(0,0);}
document.querySelectorAll("nav a[data-v]").forEach(a=>a.onclick=()=>go(a.dataset.v));
$("#imp").onclick=()=>go("import");$("#nn").onclick=newNote;
$("#q").onkeydown=e=>e.key==="Enter"&&go("search",e.target.value.trim().slice(0,100));
$("#aibtn").onclick=$("#fab").onclick=()=>{$("#aip").hidden=!$("#aip").hidden;if(!$("#aip").hidden)aiPanel();};

/* ---------- views ---------- */
const row=n=>`<div class="row" data-id="${esc(n.id)}"><span>${icon(n.file_type||"md")} ${esc(n.title)}</span><span class="mu">${fmt(n.updated_at)}</span></div>`;
const bindRows=()=>document.querySelectorAll("[data-id]").forEach(e=>e.onclick=()=>go("note",e.dataset.id));
function dashboard(){const S=subjects();
  $("#main").innerHTML=`<h1>Welcome back</h1><p class="mu">Here's an overview of your workspace.</p>
  <div class="two"><div class="card"><h2>Recent Files <a class="mu" style="float:right;font-weight:400;cursor:pointer" id="va">View all</a></h2>
  ${notes.slice(0,7).map(row).join("")||'<p class="mu">No notes yet — create or import one.</p>'}</div>
  <div class="card"><h2>Subjects</h2><div class="grid">${Object.entries(S).map(([k,v])=>`<div class="card sub" data-s="${esc(k)}"><div class="ic">📁</div><b>${esc(k)}</b><div class="mu">${v.length} notes</div></div>`).join("")||'<p class="mu">Subjects appear as you add notes.</p>'}</div></div></div>`;
  bindRows();$("#va").onclick=()=>go("library");
  document.querySelectorAll("[data-s]").forEach(e=>e.onclick=()=>{selSub=e.dataset.s;go("library");});}

function search(q){const t=(q||"").toLowerCase();const r=notes.filter(n=>(n.title+n.subject).toLowerCase().includes(t));
  $("#main").innerHTML=`<h1>Results for “${esc(q)}”</h1><div class="card">${r.map(n=>`<div class="row" data-id="${esc(n.id)}"><span>${icon(n.file_type||"md")} ${esc(n.title)} <span class="tag">${esc(n.subject)}</span></span><span class="mu">${fmt(n.updated_at)}</span></div>`).join("")||'<p class="mu">No matches in titles. Try asking the AI Assistant.</p>'}</div>`;bindRows();}

function imp(){const rec=notes.filter(n=>n.file_path).slice(0,8);
  $("#main").innerHTML=`<h1>Import your files</h1><p class="mu">PDF, DOCX, PPTX, XLSX, CSV, TXT, MD, PNG/JPG/GIF/WEBP and code (max 20 MB each).</p>
  <div class="drop" id="dz"><div style="font-size:2em">⬆</div><b>Drag files here or <span style="color:var(--pr)">click to browse</span></b></div>
  <div class="card" style="margin-top:18px"><h2>Recent imports</h2>${rec.map(n=>`<div class="row" data-id="${esc(n.id)}"><span>${icon(n.file_type)} ${esc(n.title)}</span><span class="tag">${esc((n.file_type||"").toUpperCase())}</span><span class="mu">${fmt(n.created_at)}</span></div>`).join("")||'<p class="mu">Nothing imported yet.</p>'}</div>`;
  bindRows();const dz=$("#dz");dz.onclick=()=>$("#fi").click();
  dz.ondragover=e=>e.preventDefault();dz.ondrop=e=>{e.preventDefault();doImport(e.dataTransfer.files);};}
$("#fi").onchange=e=>{go("import");doImport(e.target.files);e.target.value="";};

const CODE="js ts jsx tsx py java c cpp h go rs rb php html css json sh sql yml yaml xml kt swift".split(" "),IMG="png jpg jpeg gif webp".split(" ");
const MIME={pdf:"application/pdf",docx:"application/vnd.openxmlformats-officedocument.wordprocessingml.document",pptx:"application/vnd.openxmlformats-officedocument.presentationml.presentation",xlsx:"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",csv:"text/csv",png:"image/png",jpg:"image/jpeg",jpeg:"image/jpeg",gif:"image/gif",webp:"image/webp"};
const MAGIC={pdf:[0x25,0x50,0x44,0x46],docx:[0x50,0x4b,3,4],pptx:[0x50,0x4b,3,4],xlsx:[0x50,0x4b,3,4],png:[0x89,0x50,0x4e,0x47],jpg:[0xff,0xd8,0xff],jpeg:[0xff,0xd8,0xff],gif:[0x47,0x49,0x46,0x38],webp:[0x52,0x49,0x46,0x46]};
const ALLOWED=[..."pdf docx pptx xlsx csv txt md".split(" "),...CODE,...IMG];
async function validFile(f,ext){const m=MAGIC[ext],b=new Uint8Array(await f.slice(0,4096).arrayBuffer());
  return m?m.every((v,i)=>b[i]===v):!b.includes(0);} // text types must not contain NUL bytes
async function zipOf(ab){const z=await JSZip.loadAsync(ab);const names=Object.keys(z.files);if(names.length>3000)throw new Error("Archive too large");
  let tot=0;for(const n of names)tot+=z.files[n]._data?.uncompressedSize||0;if(tot>200e6)throw new Error("Archive expands too much");return z;}
const xml=async(z,p)=>z.file(p)?new DOMParser().parseFromString(await z.file(p).async("string"),"application/xml"):null;
const csvCell=s=>/[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;
async function xlsxText(ab){const z=await zipOf(ab),ss=await xml(z,"xl/sharedStrings.xml"),wb=await xml(z,"xl/workbook.xml");
  const S=ss?[...ss.getElementsByTagName("si")].map(si=>[...si.getElementsByTagName("t")].map(t=>t.textContent).join("")):[];
  const names=wb?[...wb.getElementsByTagName("sheet")].map(s=>s.getAttribute("name")):[];
  const files=Object.keys(z.files).filter(n=>/^xl\/worksheets\/sheet\d+\.xml$/.test(n)).sort((a,b)=>a.match(/\d+/)-b.match(/\d+/)).slice(0,20);let out="";
  for(let i=0;i<files.length;i++){const d=await xml(z,files[i]),rows=[];let n=0;if(!d)continue;
    for(const r of d.getElementsByTagName("row")){const cells=[];
      for(const c of r.getElementsByTagName("c")){const col=[...(c.getAttribute("r")||"").replace(/\d+/g,"")].reduce((a,ch)=>a*26+ch.charCodeAt(0)-64,0)-1;if(col<0||col>200)continue;
        const v=c.getElementsByTagName("v")[0]?.textContent??c.getElementsByTagName("t")[0]?.textContent??"";cells[col]=c.getAttribute("t")==="s"?(S[+v]??""):v;}
      rows.push(Array.from(cells,x=>csvCell(x??"")).join(","));if(++n>5000)break;}
    out+=`## ${(names[i]||"Sheet "+(i+1)).replace(/[`#\n]/g,"")}\n\`\`\`csv\n${rows.join("\n").replace(/```/g,"'''")}\n\`\`\`\n\n`;}return out;}
const fence=(l,t)=>"```"+l+"\n"+t.replace(/```/g,"'''")+"\n```";
async function extract(f,ext){const ab=()=>f.arrayBuffer();let t="";
  if(["txt","md"].includes(ext))t=await f.text();
  else if(CODE.includes(ext))t=fence(ext,await f.text());
  else if(ext==="csv")t=fence("csv",await f.text());
  else if(ext==="pdf"){const pdf=await import(new URL("vendor/pdf.min.mjs",location.href).href);pdf.GlobalWorkerOptions.workerSrc=new URL("vendor/pdf.worker.min.mjs",location.href).href;
    const d=await pdf.getDocument({data:await ab(),isEvalSupported:false,enableXfa:false}).promise;
    for(let i=1;i<=Math.min(d.numPages,200)&&t.length<MAXTXT;i++){t+=(await(await d.getPage(i)).getTextContent()).items.map(x=>x.str).join(" ")+"\n\n";}}
  else if(ext==="docx"){const b=await ab();await zipOf(b);await loadScript("vendor/mammoth.browser.min.js");t=(await window.mammoth.extractRawText({arrayBuffer:b})).value;}
  else if(ext==="xlsx")t=await xlsxText(await ab());
  else if(ext==="pptx"){const z=await zipOf(await ab());const sl=Object.keys(z.files).filter(n=>/^ppt\/slides\/slide\d+\.xml$/.test(n)).sort((a,b)=>a.match(/\d+/)-b.match(/\d+/)).slice(0,300);
    for(let i=0;i<sl.length;i++){const d=await xml(z,sl[i]);t+=`## Slide ${i+1}\n`+[...(d?.getElementsByTagName("a:t")||[])].map(n=>n.textContent).join("\n")+"\n\n";}}
  return t.slice(0,MAXTXT);}
async function doImport(files){
  for(const f of files){const ext=f.name.split(".").pop().toLowerCase();
    if(!ALLOWED.includes(ext)){toast(`${f.name}: unsupported file type`,1);continue;}
    if(f.size>20e6){toast(`${f.name}: larger than 20 MB`,1);continue;}
    try{if(!await validFile(f,ext))throw new Error("content does not match file type");toast("Importing "+f.name+"…");
      const text=await extract(f,ext),path=`${auth.currentUser.uid}/${crypto.randomUUID()}-${safeName(f.name)}`;
      const up=await sb.storage.from("files").upload(path,f,{contentType:MIME[ext]||"text/plain",upsert:false});if(up.error)throw up.error;
      const type=IMG.includes(ext)?"img":CODE.includes(ext)?"code":ext;
      const r=await sb.from("notes").insert({title:f.name.replace(/\.[^.]+$/,"").slice(0,200)||"Untitled",content:text,file_path:path,file_type:type,subject:"Imported"});
      if(r.error){await sb.storage.from("files").remove([path]);throw r.error;}toast(f.name+" imported");}
    catch(e){toast(`${f.name}: import failed (${e.message||"error"})`,1);}}
  await load();if(view==="import")imp();}

function fcs(box,list){box.replaceChildren(...arr(list,12).map(c=>{const q=String(c?.q??"").slice(0,300),a=String(c?.a??"").slice(0,600),e=document.createElement("div"),d=document.createElement("div");let s=false;
  e.className="fc";d.textContent=q;d.style.fontWeight="700";e.append(d);e.onclick=()=>{s=!s;d.textContent=s?a:q;d.style.fontWeight=s?"400":"700";};return e;}));}
const strs=(x,n)=>arr(x,n).map(v=>String(v).slice(0,400));

function library(){const S=subjects(),keys=Object.keys(S);selSub=S[selSub]?selSub:keys[0];
  $("#main").innerHTML=`<h1>Subject Library</h1><p class="mu">Organize and explore your knowledge areas.</p>
  <div class="two"><div class="card">${keys.map(k=>`<div class="row" data-k="${esc(k)}" style="${k===selSub?"color:var(--pr);font-weight:700":""}"><span>📁 ${esc(k)}</span><span class="mu">${S[k].length} ›</span></div>`).join("")||'<p class="mu">No subjects yet.</p>'}</div>
  <div class="card" id="sd">${selSub?`<h2>${esc(selSub)}</h2>${S[selSub].map(row).join("")}<p><button class="btn" id="kit">✦ Generate study kit</button></p><div id="kitout"></div>`:'<p class="mu">Create or import a note to begin.</p>'}</div></div>`;
  bindRows();document.querySelectorAll("[data-k]").forEach(e=>e.onclick=()=>{selSub=e.dataset.k;library();});
  $("#kit")&&($("#kit").onclick=async()=>{const b=$("#kit");b.disabled=true;b.textContent="Generating…";
    try{const{data}=await sb.from("notes").select("title,content").eq("subject",selSub).limit(8);
      const j=jparse(await ai("kit",data.map(n=>"# "+n.title+"\n"+n.content.slice(0,1500)).join("\n\n")));
      $("#kitout").innerHTML=`<h2>Overview</h2><p>${esc(String(j.overview||"").slice(0,1000))}</p><h2>Key Concepts</h2><ul>${strs(j.concepts,6).map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h2>Important Questions</h2><ul>${strs(j.questions,6).map(x=>`<li>${esc(x)}</li>`).join("")}</ul><h2>Flashcards</h2><div class="grid" id="kfc"></div><h2 style="margin-top:14px">Revision Checklist</h2>${strs(j.checklist,6).map(x=>`<label style="display:block"><input type="checkbox" style="width:auto"> ${esc(x)}</label>`).join("")}`;fcs($("#kfc"),j.cards);
    }catch(e){toast(e.message,1);}b.disabled=false;b.textContent="✦ Generate study kit";});}

/* ---------- editor ---------- */
async function newNote(){const r=await sb.from("notes").insert({title:"Untitled",content:"# Untitled\n\n",subject:selSub||"General"}).select().single();
  if(r.error)return toast(r.error.message,1);await load();go("note",r.data.id);}
async function openNote(id){if(!UUID.test(id||""))return;const{data,error}=await sb.from("notes").select("*").eq("id",id).single();if(error)return toast(error.message,1);cur=data;dirty=false;
  $("#main").innerHTML=`<div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center"><input id="nt" maxlength="200" style="flex:2;min-width:180px;font-weight:700" value="${esc(cur.title)}"><input id="ns" maxlength="100" list="sl" style="flex:1;min-width:120px" value="${esc(cur.subject)}"><datalist id="sl">${Object.keys(subjects()).map(s=>`<option value="${esc(s)}">`).join("")}</datalist>
  <span class="mu" id="st">All changes saved</span><button class="btn sec" id="ex">Export</button><button class="btn" id="sv">Save</button><button class="btn sec" id="dl" style="color:var(--er)">Delete</button></div>
  <div class="tb">${[["H","# "],["B","**"],["I","_"],["🔗","link"],["</>","```"],["❝","> "],["•","- "],["Mermaid","mm"]].map(([l,k])=>`<button class="btn sec" data-k="${esc(k)}">${esc(l)}</button>`).join("")}
  <button class="btn sec" id="pv">👁 Preview</button>${cur.file_path?'<button class="btn sec" id="og">⬇ Original file</button>':""}</div>
  <div class="ed" id="ed"><textarea class="src" id="src" maxlength="2000000" ${P.spell?"":'spellcheck="false"'}>${esc(cur.content)}</textarea><div class="card prev" id="prev"></div></div><p class="mu" id="wc"></p>`;
  const src=$("#src");let mm=false;
  const render=async()=>{$("#prev").innerHTML=md2html(src.value);
    const blocks=[...document.querySelectorAll("#prev code.language-mermaid")];
    if(blocks.length){try{await loadScript("vendor/mermaid.min.js");if(!mm){window.mermaid.initialize({startOnLoad:false,securityLevel:"strict",theme:"neutral",flowchart:{htmlLabels:false}});mm=true;}
      blocks.forEach(c=>{const d=document.createElement("div");d.className="mermaid";d.textContent=c.textContent;c.parentElement.replaceWith(d);});
      await window.mermaid.run({nodes:document.querySelectorAll("#prev .mermaid")});}catch{}}
    const w=src.value.trim().split(/\s+/).filter(Boolean).length;$("#wc").textContent=`${w} words · ${Math.max(1,Math.round(w/200))} min read`;};
  render();$("#ed").classList.toggle("one",!prevOn);$("#prev").hidden=!prevOn;
  const mark=()=>{dirty=true;$("#st").textContent="Unsaved changes…";render();clearTimeout(timer);if(P.auto)timer=setTimeout(save,1500);};
  src.oninput=$("#nt").oninput=$("#ns").oninput=mark;
  $("#pv").onclick=()=>{prevOn=!prevOn;$("#ed").classList.toggle("one",!prevOn);$("#prev").hidden=!prevOn;};
  $("#sv").onclick=save;$("#ex").onclick=exportNote;
  $("#dl").onclick=async()=>{if(!confirm("Delete this note?"))return;if(cur.file_path)await sb.storage.from("files").remove([cur.file_path]);await sb.from("notes").delete().eq("id",cur.id);dirty=false;await load();cur=null;go("library");};
  $("#og")&&($("#og").onclick=async()=>{const{data}=await sb.storage.from("files").createSignedUrl(cur.file_path,120,{download:true});data&&window.open(data.signedUrl,"_blank","noopener,noreferrer");});
  document.querySelectorAll(".tb [data-k]").forEach(b=>b.onclick=()=>{const k=b.dataset.k,s=src.selectionStart,e=src.selectionEnd,t=src.value.slice(s,e)||"text";let r;
    if(["**","_"].includes(k))r=k+t+k;else if(k==="```")r="```\n"+t+"\n```";else if(k==="link")r=`[${t}](https://)`;else if(k==="mm")r="```mermaid\ngraph TD\n  A[Start] --> B[Next]\n```";else r=k+t;
    src.setRangeText(r,s,e,"end");src.focus();mark();});}
async function save(){if(!cur||!dirty)return;clearTimeout(timer);const c=$("#src").value;if(c.length>2e6)return toast("Note too large (2M chars max)",1);$("#st").textContent="Saving…";
  const u={title:($("#nt").value||"Untitled").slice(0,200),subject:($("#ns").value||"General").slice(0,100),content:c};
  const{error}=await sb.from("notes").update(u).eq("id",cur.id);if(error){$("#st").textContent="Save failed";return toast(error.message,1);}
  Object.assign(cur,u);dirty=false;$("#st").textContent="All changes saved";await load();}
const dlf=(n,t,m)=>{const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([t],{type:m}));a.download=safeName(n);a.click();setTimeout(()=>URL.revokeObjectURL(a.href),5000);};
function exportNote(){const c=(prompt("Export as: md, html, doc, pdf","md")||"").trim();if(!c)return;const t=$("#nt").value,md=$("#src").value,
  page=`<!doctype html><meta charset=utf-8><meta http-equiv="Content-Security-Policy" content="default-src 'none'; style-src 'unsafe-inline'"><title>${esc(t)}</title><body style="font-family:sans-serif;max-width:800px;margin:auto">${md2html(md)}`;
  if(c==="md")dlf(t+".md",md,"text/markdown");else if(c==="html")dlf(t+".html",page,"text/html");else if(c==="doc")dlf(t+".doc",page,"application/msword");
  else if(c==="pdf"){const f=document.createElement("iframe");f.sandbox="allow-same-origin allow-modals";f.style.cssText="position:fixed;width:0;height:0;border:0";f.onload=()=>{f.contentWindow.focus();f.contentWindow.print();setTimeout(()=>f.remove(),60000);};f.srcdoc=page;document.body.append(f);}}

/* ---------- settings ---------- */
function settings(){$("#main").innerHTML=`<h1>Settings</h1><p class="mu">Customize your workspace preferences.</p><div class="card" style="max-width:560px">
  <div class="sw"><b>Theme</b><select id="th" style="width:auto"><option>light</option><option>dark</option></select></div>
  <div class="sw"><b>Font size</b><select id="fs" style="width:auto"><option value="14">Small</option><option value="16">Medium</option><option value="19">Large</option></select></div>
  <div class="sw"><span><b>Auto-save</b><br><span class="mu">Automatically save changes</span></span><input type="checkbox" id="au"></div>
  <div class="sw"><span><b>Spell check</b><br><span class="mu">Check spelling while typing</span></span><input type="checkbox" id="sp"></div>
  <div class="sw"><b>Export all notes</b><button class="btn sec" id="ea">Download .md</button></div>
  <div class="sw"><b>Delete all my data</b><button class="btn sec" id="da" style="color:var(--er)">Delete…</button></div>
  <div class="sw"><span class="mu">${esc(auth.currentUser.email)}</span><button class="btn sec" id="so">Sign out</button></div></div>`;
  $("#th").value=P.theme;$("#fs").value=String(P.fs);$("#au").checked=P.auto;$("#sp").checked=P.spell;
  $("#th").onchange=e=>{P.theme=e.target.value==="dark"?"dark":"light";saveP();};$("#fs").onchange=e=>{P.fs=[14,16,19].includes(+e.target.value)?+e.target.value:16;saveP();};
  $("#au").onchange=e=>{P.auto=e.target.checked;saveP();};$("#sp").onchange=e=>{P.spell=e.target.checked;saveP();};$("#so").onclick=()=>signOut(auth);
  $("#ea").onclick=async()=>{const{data}=await sb.from("notes").select("title,subject,content");dlf("arc-notes.md",(data||[]).map(n=>`# ${n.title}\n_Subject: ${n.subject}_\n\n${n.content}`).join("\n\n---\n\n"),"text/markdown");};
  $("#da").onclick=async()=>{if(prompt("Type DELETE to permanently erase all your notes and files")!=="DELETE")return;const uid=auth.currentUser.uid;
    for(let i=0;i<50;i++){const{data:fl}=await sb.storage.from("files").list(uid,{limit:100});if(!fl?.length)break;await sb.storage.from("files").remove(fl.map(f=>`${uid}/${f.name}`));}
    const{error}=await sb.from("notes").delete().not("id","is",null);if(error)return toast(error.message,1);await load();toast("All data deleted");};}

/* ---------- AI panel ---------- */
async function context(q){if(cur&&view==="note")return"Note \""+cur.title+"\":\n"+($("#src")?.value||cur.content).slice(0,9000);
  const kw=(q.match(/[\p{L}\p{N}]{4,}/gu)||[]).slice(0,4);if(!kw.length)return"";
  const{data}=await sb.from("notes").select("title,content").or(kw.map(k=>`title.ilike.%${k}%,content.ilike.%${k}%`).join(",")).limit(3);
  return(data||[]).map(n=>`Note "${n.title}":\n${n.content.slice(0,3000)}`).join("\n\n");}
function aiPanel(){const p=$("#aip");p.innerHTML=`<div style="display:flex;justify-content:space-between"><b>AI Assistant</b><a style="cursor:pointer" id="ax">✕</a></div>
  <div class="tabs">${["chat","summary","flashcards"].map(t=>`<button class="btn ${t===aiTab?"":"sec"}" data-t="${t}">${t}</button>`).join("")}</div><div class="body" id="ab"></div><div id="af"></div>`;
  $("#ax").onclick=()=>p.hidden=true;p.querySelectorAll("[data-t]").forEach(b=>b.onclick=()=>{aiTab=b.dataset.t;aiPanel();});
  const body=$("#ab"),f=$("#af"),inNote=cur&&view==="note";
  if(aiTab==="chat"){body.innerHTML=chat.map(m=>`<div class="msg ${m.role==="user"?"u":"a"}">${esc(m.content)}</div>`).join("")||`<p class="mu">Ask a question about ${inNote?"this note":"your notes"}…</p>`;
    f.innerHTML=`<form style="display:flex;gap:8px"><input id="cq" maxlength="1000" placeholder="Ask a question about your notes…"><button class="btn">Send</button></form>`;body.scrollTop=1e9;
    f.firstChild.onsubmit=async e=>{e.preventDefault();const q=$("#cq").value.trim();if(!q)return;chat.push({role:"user",content:q});aiPanel();
      try{chat.push({role:"assistant",content:await ai("chat",await context(q),chat.slice(-8))});}catch(x){chat.push({role:"assistant",content:"Error: "+x.message});}aiPanel();};}
  else{body.innerHTML=inNote?"":'<p class="mu">Open a note first.</p>';f.innerHTML=inNote?`<button class="btn" style="width:100%" id="go">${aiTab==="summary"?"Summarize this note":"Generate flashcards"}</button>`:"";
    if(aiTab==="flashcards"&&cards.length)fcs(body,cards);
    $("#go")&&($("#go").onclick=async()=>{const b=$("#go");b.disabled=true;b.textContent="Working…";const c=($("#src")?.value||cur.content).slice(0,10000);
      try{if(aiTab==="summary"){body.innerHTML=`<div class="msg a">${esc(await ai("summary",c))}</div>`;}else{cards=arr(jparse(await ai("cards",c)).cards,12);fcs(body,cards);}}
      catch(x){toast(x.message,1);}b.disabled=false;b.textContent="Regenerate";});}}
